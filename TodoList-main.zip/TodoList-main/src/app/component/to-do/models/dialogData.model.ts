export interface DialogData {
  title: string;
  data: any;
}
