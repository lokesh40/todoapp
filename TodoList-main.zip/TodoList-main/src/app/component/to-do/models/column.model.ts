import { Task } from "./task.mode";

export class Column{
  constructor(public name: string, public task: Task[]){}
}
