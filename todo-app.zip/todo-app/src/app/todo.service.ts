import { Injectable } from '@angular/core';
import { Todo } from './to-do.model';

@Injectable({
  providedIn: 'root'
})
export class TodoService {
  private todos: Todo[] = [
    new Todo(1, 'Learn Angular', false),
    new Todo(2, 'Build an app', false),
  ];

  constructor() { }

  getTodos(): Todo[] {
    return this.todos;
  }

  addTodo(title: string): void {
    const id = this.todos.length ? Math.max(...this.todos.map(todo => todo.id)) + 1 : 1;
    this.todos.push(new Todo(id, title, false));
  }

  toggleTodoCompletion(id: number): void {
    const todo = this.todos.find(todo => todo.id === id);
    if (todo) {
      todo.completed = !todo.completed;
    }
  }

  deleteTodo(id: number): void {
    this.todos = this.todos.filter(todo => todo.id !== id);
  }
}
